# NEET MASTER — starter project

A responsive React + Vite starter for a NEET UG learning platform.

## Included in this starter
- Responsive dashboard and subject navigation
- Chapter/topic-group navigation for Physics, Chemistry and Biology (2026 syllabus-based grouping; verify against the latest official syllabus)
- Demo MCQ practice with answer explanations and +4/-1 scoring
- Resource links for NTA syllabus, NTA notices, NCERT ePathshala, NTA IIT-PAL lectures and a third-party PYQ index
- Notes, mock tests and PYQ pages ready to expand

## Important content note
This is a working starter, not a complete verified NEET question bank or complete notes library. The nine questions are demonstration questions only. Before publishing for students, add teacher-reviewed notes, chapter-mapped questions, official final answer keys, paper-code labels and current syllabus mapping. Do not upload pirated coaching PDFs or copy paid course content. Link to authorised resources where possible.

## Run on your computer
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP.
3. Open the extracted `neet-master-starter` folder in VS Code.
4. Open Terminal > New Terminal.
5. Run:

   npm install
   npm run dev

6. Open the local URL shown in the terminal (usually http://localhost:5173).

To create a production build:

   npm run build

The built website is created in `dist/`.

## Publish free using GitHub + Vercel
1. Create/sign in to https://github.com/
2. Click New repository. Name it `neet-master`. Choose Public (or Private if preferred), then Create repository.
3. In VS Code, open this project folder and run:

   git init
   git add .
   git commit -m "Initial NEET MASTER website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/neet-master.git
   git push -u origin main

   Replace YOUR-USERNAME with your GitHub username. If Git asks you to sign in, complete the browser authentication.

4. Visit https://vercel.com/ and sign in with GitHub.
5. Choose Add New > Project, import `neet-master`.
6. Framework should be detected as Vite. Build command: `npm run build`. Output directory: `dist`.
7. Click Deploy. Vercel gives you a public `*.vercel.app` URL.
8. Later, edit code in VS Code and run `git add .`, `git commit -m "Update site"`, `git push`. Vercel automatically deploys the update.

## Alternative: Netlify
- Sign in at https://app.netlify.com/
- Add new project > Import an existing project > GitHub > select `neet-master`
- Build command: `npm run build`
- Publish directory: `dist`
- Publish / Deploy.

## Where to add content
- `src/questions.js`: add reviewed MCQs. Each item needs subject, chapter, q, opts (4 choices), a (zero-based correct option index), and why.
- `src/main.jsx`: add chapter notes, PYQ paper links and test modes.
- `src/style.css`: change colours/layout.
- For a real full mock test, add 180 validated questions, the current official duration and marking scheme from the relevant year's information bulletin. Do not assume old patterns remain current.

## Official starting points
- NTA NEET: https://neet.nta.nic.in/
- 2026 syllabus: https://neet.nta.nic.in/document/syllabus-for-neet-ug-2026-examination/
- NCERT ePathshala: https://epathshala.nic.in/
- NTA lectures: https://www.nta.ac.in/LecturesContent
- PYQ index (third-party): https://admission.aglasem.com/neet-question-papers/

## Suggested next build milestones
1. Complete official syllabus database with chapter/unit mapping.
2. Write original NCERT-aligned notes and formula/reaction/diagram sheets.
3. Add a reviewed PYQ bank with source, year, paper code and answer-key references.
4. Build 15/30/45-question chapter tests and a full-length mock test using the applicable exam pattern.
5. Add user accounts and cloud progress only after choosing a backend (e.g. Supabase/Firebase); keep API keys in environment variables, never in public frontend code.
