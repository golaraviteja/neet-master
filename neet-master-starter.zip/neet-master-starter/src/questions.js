export const questions = [
  {
    "subject": "Physics",
    "chapter": "Units and Measurements",
    "q": "The SI unit of force is:",
    "opts": [
      "Joule",
      "Newton",
      "Watt",
      "Pascal"
    ],
    "a": 1,
    "why": "Force = mass × acceleration; its SI unit is kg m s⁻², called newton."
  },
  {
    "subject": "Physics",
    "chapter": "Units and Measurements",
    "q": "The dimensional formula of velocity is:",
    "opts": [
      "[LT⁻¹]",
      "[LT⁻²]",
      "[MLT⁻¹]",
      "[L²T⁻¹]"
    ],
    "a": 0,
    "why": "Velocity is displacement divided by time."
  },
  {
    "subject": "Physics",
    "chapter": "Kinematics",
    "q": "The slope of a displacement-time graph represents:",
    "opts": [
      "Acceleration",
      "Force",
      "Velocity",
      "Momentum"
    ],
    "a": 2,
    "why": "The slope is change in displacement per unit time."
  },
  {
    "subject": "Chemistry",
    "chapter": "Atomic Structure",
    "q": "The maximum number of electrons in the third shell is:",
    "opts": [
      "8",
      "18",
      "32",
      "32"
    ],
    "a": 1,
    "why": "Maximum shell capacity is 2n²; for n = 3, it is 18."
  },
  {
    "subject": "Chemistry",
    "chapter": "Chemical Bonding",
    "q": "Which bond involves sharing of electron pairs?",
    "opts": [
      "Ionic",
      "Covalent",
      "Metallic",
      "Hydrogen"
    ],
    "a": 1,
    "why": "A covalent bond is formed by sharing electron pair(s)."
  },
  {
    "subject": "Chemistry",
    "chapter": "Mole Concept",
    "q": "One mole contains approximately:",
    "opts": [
      "6.022 × 10²³ entities",
      "3.011 × 10²³ entities",
      "1.6 × 10⁻¹⁹ entities",
      "9.8 entities"
    ],
    "a": 0,
    "why": "Avogadro constant is 6.02214076 × 10²³ mol⁻¹."
  },
  {
    "subject": "Biology",
    "chapter": "Cell: The Unit of Life",
    "q": "The powerhouse of the cell is:",
    "opts": [
      "Ribosome",
      "Nucleus",
      "Mitochondrion",
      "Golgi body"
    ],
    "a": 2,
    "why": "Mitochondria are major sites of aerobic ATP production."
  },
  {
    "subject": "Biology",
    "chapter": "Biomolecules",
    "q": "Enzymes are generally:",
    "opts": [
      "Lipids",
      "Proteins",
      "Minerals",
      "Nucleic acids only"
    ],
    "a": 1,
    "why": "Most enzymes are proteins; some RNA molecules also have catalytic activity."
  },
  {
    "subject": "Biology",
    "chapter": "Human Physiology",
    "q": "The functional unit of the kidney is:",
    "opts": [
      "Neuron",
      "Nephron",
      "Alveolus",
      "Villus"
    ],
    "a": 1,
    "why": "The nephron is the structural and functional unit of the kidney."
  }
];
